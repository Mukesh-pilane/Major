

def summarize(txt):
    return True